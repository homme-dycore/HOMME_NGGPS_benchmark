#!/bin/bash

cmake \
  -DCMAKE_C_COMPILER=cc \
  -DCMAKE_CXX_COMPILER=CC \
  -DCMAKE_Fortran_COMPILER=ftn \
  -DCMAKE_Fortran_FLAGS="-ffree-form -ffree-line-length-none" \
  -DPIO_FILESYSTEM_HINTS="lustre" \
  -DNUM_PLEV=26 \
  -DCMAKE_INSTALL_PREFIX=/tmp/work/$USER/homme-gnu \
  $HOMME_ROOT
