#!/bin/bash

if [ "$HOMME_ROOT" == "" ] ; then 
  echo "Must specify location of HOMME source environment variable HOMME_ROOT" 
  return -1
fi 

cmake \
-DCMAKE_BUILD_TYPE=RELEASE \
  -DCMAKE_C_COMPILER=cc \
  -DCMAKE_CXX_COMPILER=CC \
  -DCMAKE_Fortran_COMPILER=ftn \
  -DCMAKE_Fortran_FLAGS="" \
  -DPIO_FILESYSTEM_HINTS="lustre" \
  -DHOMME_ARCH=Linux \
  -DNUM_PLEV=1 \
  -DBUILD_HOMME_SWEQX=ON \
  -DBUILD_HOMME_SWIM=ON \
  -DCMAKE_INSTALL_PREFIX=/tmp/work/$USER/homme-pgi \
  $HOMME_ROOT
