#include <math.h>
double DERFC(double *arg){
return(erfc(*arg));
}
