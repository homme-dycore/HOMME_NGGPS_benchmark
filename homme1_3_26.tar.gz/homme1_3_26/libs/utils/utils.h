#ifndef UTILS_H_
#define UTILS_H_

double timer_clock();
int nbits(int n);
int precision();

#endif
