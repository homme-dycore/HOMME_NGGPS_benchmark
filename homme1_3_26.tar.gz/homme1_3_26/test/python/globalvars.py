homme_dir = "~/codes/homme"
netcdf_dir = "$NETCDF_PATH"
pnetcdf_dir = "$PNETCDF_PATH"
default_bld_dir = homme_dir+"/build"
default_out_dir = "~/scratch1/homme_out"
default_vcoord_dir = homme_dir+"/test/vcoord"
default_ncpu = 16
make_opt = "-j 4"

